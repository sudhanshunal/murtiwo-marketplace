import "server-only";
import { list, issueSignedToken, presignUrl } from "@vercel/blob";

/**
 * All Blob access happens server-side using BLOB_READ_WRITE_TOKEN.
 * We resolve files by pathname via list() instead of hardcoding public URLs,
 * so nothing here needs to assume a fixed CDN URL and the STL's real URL
 * is never sent to the browser.
 */

function getBlobToken(): string {
  const token = process.env.BLOB_READ_WRITE_TOKEN;
  if (!token) {
    throw new Error("Storage configuration error.");
  }
  return token;
}

type ResolvedBlob = {
  url: string;
  pathname: string;
  size: number;
  contentType?: string;
};

const cache = new Map<string, { value: ResolvedBlob | null; expiresAt: number }>();
const CACHE_TTL_MS = 60_000;

async function findBlobByPathname(pathname: string): Promise<ResolvedBlob | null> {
  const cached = cache.get(pathname);
  if (cached && cached.expiresAt > Date.now()) return cached.value;

  const token = getBlobToken();
  let cursor: string | undefined;
  let found: ResolvedBlob | null = null;

  // Paginate defensively in case the store has more than one page of files.
  do {
    const page = await list({ token, cursor, limit: 1000 });
    const match = page.blobs.find((b) => b.pathname === pathname);
    if (match) {
      found = {
        url: match.url,
        pathname: match.pathname,
        size: match.size,
      };
      break;
    }
    cursor = page.cursor;
  } while (cursor);

  cache.set(pathname, { value: found, expiresAt: Date.now() + CACHE_TTL_MS });
  return found;
}

/** Resolves the private STL file's current Blob object. Never return `.url` to the client. */
export async function resolveStlBlob(pathname: string): Promise<ResolvedBlob | null> {
  return findBlobByPathname(pathname);
}

/** Resolves the product preview image URL. Safe to expose — it's the public marketing image. */
export async function resolveImageUrl(pathname: string): Promise<string | null> {
  const blob = await findBlobByPathname(pathname);
  return blob?.url ?? null;
}

/**
 * Issues a genuine short-lived, scoped, signed Blob download URL for the STL —
 * this is the actual bytes source, valid only for `ttlMs` and only for a `get`
 * on this exact pathname. The permanent Blob URL/token is never exposed.
 */
export async function createShortLivedStlDownloadUrl(pathname: string, ttlMs = 10 * 60 * 1000): Promise<string | null> {
  const blob = await resolveStlBlob(pathname);
  if (!blob) return null;

  const token = getBlobToken();
  const validUntil = Date.now() + ttlMs;

  const signed = await issueSignedToken({
    token,
    pathname,
    operations: ["get"],
    validUntil,
  });

  const { presignedUrl } = await presignUrl(
    { clientSigningToken: signed.clientSigningToken, delegationToken: signed.delegationToken },
    { operation: "get", pathname, validUntil, access: "private" }
  );

  return presignedUrl;
}
