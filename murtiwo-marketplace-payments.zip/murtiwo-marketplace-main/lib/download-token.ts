import "server-only";
import crypto from "crypto";

/**
 * Short-lived, self-contained (stateless) download tokens.
 *
 * We don't have a database available, so instead of a session lookup we
 * encode {productId, orderId, paymentId, exp} and sign it with HMAC-SHA256
 * using RAZORPAY_KEY_SECRET (the only secret we're allowed to use). Anyone
 * without that secret cannot forge or extend a token, and it expires quickly.
 */

const TOKEN_TTL_MS = 10 * 60 * 1000; // 10 minutes

type TokenPayload = {
  productId: string;
  orderId: string;
  paymentId: string;
  exp: number; // epoch ms
};

function getSecret(): string {
  const secret = process.env.RAZORPAY_KEY_SECRET;
  if (!secret) throw new Error("Payment configuration error.");
  return secret;
}

function base64url(input: Buffer): string {
  return input.toString("base64url");
}

export function createDownloadToken(params: { productId: string; orderId: string; paymentId: string }): string {
  const payload: TokenPayload = {
    productId: params.productId,
    orderId: params.orderId,
    paymentId: params.paymentId,
    exp: Date.now() + TOKEN_TTL_MS,
  };
  const payloadJson = JSON.stringify(payload);
  const payloadB64 = base64url(Buffer.from(payloadJson, "utf8"));
  const signature = crypto.createHmac("sha256", getSecret()).update(payloadB64).digest("base64url");
  return `${payloadB64}.${signature}`;
}

export function verifyDownloadToken(token: string): TokenPayload | null {
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const [payloadB64, signature] = parts;

  const expectedSig = crypto.createHmac("sha256", getSecret()).update(payloadB64).digest("base64url");
  const sigBuf = Buffer.from(signature);
  const expectedBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
    return null;
  }

  try {
    const payload = JSON.parse(Buffer.from(payloadB64, "base64url").toString("utf8")) as TokenPayload;
    if (typeof payload.exp !== "number" || Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}
