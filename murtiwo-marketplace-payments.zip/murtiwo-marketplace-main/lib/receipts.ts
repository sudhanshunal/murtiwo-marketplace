import "server-only";
import { put, head } from "@vercel/blob";

/**
 * There's no database in this project, so we use a tiny JSON "receipt" per
 * order, written to Vercel Blob, as a durable record of payment state.
 *
 * - /api/verify writes a receipt the moment the browser-side signature check passes.
 * - The Razorpay webhook (independent of the browser) confirms/upgrades the same
 *   receipt when it receives `payment.captured` — this is the secondary,
 *   server-to-server source of truth the requirements ask for.
 *
 * Receipts only ever contain order/payment IDs and status flags — never secrets.
 */

export type Receipt = {
  orderId: string;
  paymentId: string;
  productId: string;
  verifiedAt?: string;
  webhookConfirmedAt?: string;
  status: "verified" | "webhook_confirmed" | "failed";
};

function getBlobToken(): string {
  const token = process.env.BLOB_READ_WRITE_TOKEN;
  if (!token) throw new Error("Storage configuration error.");
  return token;
}

function receiptPathname(orderId: string): string {
  return `receipts/${orderId}.json`;
}

export async function writeReceipt(receipt: Receipt): Promise<void> {
  const token = getBlobToken();
  await put(receiptPathname(receipt.orderId), JSON.stringify(receipt), {
    access: "public",
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: "application/json",
    token,
  });
}

export async function readReceipt(orderId: string): Promise<Receipt | null> {
  const token = getBlobToken();
  try {
    const meta = await head(receiptPathname(orderId), { token });
    const res = await fetch(meta.url, { cache: "no-store" });
    if (!res.ok) return null;
    return (await res.json()) as Receipt;
  } catch {
    return null;
  }
}

export async function markWebhookConfirmed(orderId: string, paymentId: string, productId: string): Promise<void> {
  const existing = await readReceipt(orderId);
  const receipt: Receipt = {
    orderId,
    paymentId,
    productId: existing?.productId ?? productId,
    verifiedAt: existing?.verifiedAt,
    webhookConfirmedAt: new Date().toISOString(),
    status: "webhook_confirmed",
  };
  await writeReceipt(receipt);
}
