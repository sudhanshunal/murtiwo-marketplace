/**
 * Product catalog. Kept simple (no DB) since there's a single paid product today.
 * Price is defined in paise (smallest INR unit) so it's unambiguous for Razorpay.
 */
export type Product = {
  id: string;
  name: string;
  formats: string[];
  priceInPaise: number;
  currency: "INR";
  /** Vercel Blob pathname of the private STL file (looked up server-side, never exposed to the client). */
  blobPathname: string;
  /** Vercel Blob pathname of the preview image (also resolved server-side). */
  imageBlobPathname: string;
};

export const LION_MURTI_STL: Product = {
  id: "lion-murti-stl",
  name: "Lion Murti STL",
  formats: ["STL", "3DM"],
  priceInPaise: 1000, // ₹10.00
  currency: "INR",
  blobPathname: "LION.stl",
  imageBlobPathname: "lion image",
};

export function getProductById(id: string): Product | null {
  if (id === LION_MURTI_STL.id) return LION_MURTI_STL;
  return null;
}

export function formatPaiseAsINR(paise: number): string {
  return `₹${(paise / 100).toFixed(2)}`;
}
