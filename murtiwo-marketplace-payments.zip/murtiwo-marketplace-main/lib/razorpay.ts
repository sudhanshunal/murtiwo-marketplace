import "server-only";
import Razorpay from "razorpay";
import crypto from "crypto";

/**
 * Server-only Razorpay helpers.
 *
 * IMPORTANT: RAZORPAY_KEY_SECRET must NEVER be sent to the client, logged,
 * or included in any error message returned from an API route.
 */

function getEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    // Deliberately generic — never echo the variable name/value to a client-facing response.
    throw new Error("Payment configuration error.");
  }
  return value;
}

let razorpayClient: Razorpay | null = null;

export function getRazorpayClient(): Razorpay {
  if (razorpayClient) return razorpayClient;
  razorpayClient = new Razorpay({
    key_id: getEnv("RAZORPAY_KEY_ID"),
    key_secret: getEnv("RAZORPAY_KEY_SECRET"),
  });
  return razorpayClient;
}

export function getRazorpayKeyId(): string {
  return getEnv("RAZORPAY_KEY_ID");
}

/**
 * Verifies the signature Razorpay Checkout returns to the browser after payment:
 * expected_signature = HMAC_SHA256(order_id + "|" + payment_id, key_secret)
 */
export function verifyCheckoutSignature(params: {
  orderId: string;
  paymentId: string;
  signature: string;
}): boolean {
  const secret = getEnv("RAZORPAY_KEY_SECRET");
  const expected = crypto
    .createHmac("sha256", secret)
    .update(`${params.orderId}|${params.paymentId}`)
    .digest("hex");

  return timingSafeEqualHex(expected, params.signature);
}

/**
 * Verifies an incoming Razorpay webhook request.
 * Razorpay signs the RAW request body with the webhook secret and sends it
 * in the `x-razorpay-signature` header.
 *
 * Per project constraints we only have RAZORPAY_KEY_SECRET available as an
 * env var, so the same value must be configured as the "Webhook Secret" in
 * the Razorpay Dashboard (Settings -> Webhooks) for this to validate.
 */
export function verifyWebhookSignature(rawBody: string, signatureHeader: string | null): boolean {
  if (!signatureHeader) return false;
  const secret = getEnv("RAZORPAY_KEY_SECRET");
  const expected = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  return timingSafeEqualHex(expected, signatureHeader);
}

function timingSafeEqualHex(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  try {
    return crypto.timingSafeEqual(Buffer.from(a, "hex"), Buffer.from(b, "hex"));
  } catch {
    return false;
  }
}
