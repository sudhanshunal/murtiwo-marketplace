import { NextRequest, NextResponse } from "next/server";
import { verifyDownloadToken } from "@/lib/download-token";
import { getProductById } from "@/lib/products";
import { createShortLivedStlDownloadUrl } from "@/lib/blob";
import { readReceipt } from "@/lib/receipts";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get("token");

  if (!token) {
    return NextResponse.json({ error: "Payment could not be verified. No download was issued." }, { status: 401 });
  }

  const payload = verifyDownloadToken(token);
  if (!payload) {
    return NextResponse.json({ error: "Payment could not be verified. No download was issued." }, { status: 401 });
  }

  const product = getProductById(payload.productId);
  if (!product) {
    return NextResponse.json({ error: "Payment could not be verified. No download was issued." }, { status: 401 });
  }

  // Cross-check against the receipt written at verification time (and possibly
  // upgraded by the webhook) — a valid token alone isn't enough; there must
  // also be a recorded, signature-verified payment for this order.
  const receipt = await readReceipt(payload.orderId);
  if (!receipt || receipt.paymentId !== payload.paymentId || receipt.status === "failed") {
    return NextResponse.json({ error: "Payment could not be verified. No download was issued." }, { status: 401 });
  }

  try {
    const url = await createShortLivedStlDownloadUrl(product.blobPathname, 5 * 60 * 1000);
    if (!url) {
      return NextResponse.json({ error: "File temporarily unavailable. Please contact support." }, { status: 404 });
    }
    // Redirect to a freshly signed, short-lived Blob URL — the permanent
    // Blob URL/token is never sent to or stored by the browser.
    return NextResponse.redirect(url, { status: 302 });
  } catch {
    return NextResponse.json({ error: "Download failed. Please try again." }, { status: 502 });
  }
}
