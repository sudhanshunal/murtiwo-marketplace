import { NextRequest, NextResponse } from "next/server";
import { verifyCheckoutSignature } from "@/lib/razorpay";
import { getProductById } from "@/lib/products";
import { createDownloadToken } from "@/lib/download-token";
import { writeReceipt } from "@/lib/receipts";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ verified: false, message: "Payment could not be verified. No download was issued." }, { status: 400 });
  }

  const b = body as {
    productId?: string;
    razorpay_order_id?: string;
    razorpay_payment_id?: string;
    razorpay_signature?: string;
  };

  const product = b.productId ? getProductById(b.productId) : null;

  if (!product || !b.razorpay_order_id || !b.razorpay_payment_id || !b.razorpay_signature) {
    return NextResponse.json({ verified: false, message: "Payment could not be verified. No download was issued." }, { status: 400 });
  }

  const isValid = verifyCheckoutSignature({
    orderId: b.razorpay_order_id,
    paymentId: b.razorpay_payment_id,
    signature: b.razorpay_signature,
  });

  if (!isValid) {
    return NextResponse.json({ verified: false, message: "Payment could not be verified. No download was issued." }, { status: 400 });
  }

  try {
    await writeReceipt({
      orderId: b.razorpay_order_id,
      paymentId: b.razorpay_payment_id,
      productId: product.id,
      verifiedAt: new Date().toISOString(),
      status: "verified",
    });
  } catch {
    // If we can't record the receipt, fail closed rather than issuing a token silently.
    return NextResponse.json({ verified: false, message: "Payment could not be verified. No download was issued." }, { status: 502 });
  }

  const token = createDownloadToken({
    productId: product.id,
    orderId: b.razorpay_order_id,
    paymentId: b.razorpay_payment_id,
  });

  return NextResponse.json({
    verified: true,
    message: "Payment verified. Your protected download is ready.",
    downloadUrl: `/api/download?token=${encodeURIComponent(token)}`,
  });
}
