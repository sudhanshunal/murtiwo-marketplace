import { NextRequest, NextResponse } from "next/server";
import { getRazorpayClient, getRazorpayKeyId } from "@/lib/razorpay";
import { getProductById } from "@/lib/products";
import crypto from "crypto";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }

  const productId = typeof (body as { productId?: unknown })?.productId === "string" ? (body as { productId: string }).productId : null;
  const product = productId ? getProductById(productId) : null;

  if (!product) {
    return NextResponse.json({ error: "Unknown product." }, { status: 400 });
  }

  try {
    const razorpay = getRazorpayClient();

    // A fresh order every attempt — receipt id is unique per request, not reused.
    const receiptId = `rcpt_${crypto.randomBytes(8).toString("hex")}`;

    const order = await razorpay.orders.create({
      amount: product.priceInPaise, // 1000 paise = ₹10 for the Lion Murti STL
      currency: product.currency,
      receipt: receiptId,
      notes: { productId: product.id },
    });

    return NextResponse.json({
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      keyId: getRazorpayKeyId(),
      productName: product.name,
    });
  } catch {
    // Never leak internal error detail (could contain config/secret hints).
    return NextResponse.json({ error: "Could not start checkout. Please try again." }, { status: 502 });
  }
}
