import { NextRequest, NextResponse } from "next/server";
import { verifyWebhookSignature } from "@/lib/razorpay";
import { markWebhookConfirmed } from "@/lib/receipts";

export const runtime = "nodejs";

/**
 * Razorpay webhook — the secondary, server-to-server source of truth for
 * payment status, independent of whatever happens in the customer's browser.
 *
 * Configure this URL in Razorpay Dashboard -> Settings -> Webhooks as:
 *   https://<your-domain>/api/webhook/razorpay
 * and set the Webhook Secret there to the SAME value as RAZORPAY_KEY_SECRET
 * (this project only uses the three env vars listed in the requirements,
 * so the webhook secret and the API key secret must match).
 * Enable at least the "payment.captured" event.
 */
export async function POST(req: NextRequest) {
  const rawBody = await req.text();
  const signature = req.headers.get("x-razorpay-signature");

  if (!verifyWebhookSignature(rawBody, signature)) {
    // Do not reveal *why* verification failed.
    return NextResponse.json({ error: "Invalid signature." }, { status: 400 });
  }

  let event: unknown;
  try {
    event = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: "Invalid payload." }, { status: 400 });
  }

  const e = event as {
    event?: string;
    payload?: {
      payment?: {
        entity?: {
          id?: string;
          order_id?: string;
          status?: string;
          notes?: { productId?: string };
        };
      };
    };
  };

  try {
    if (e.event === "payment.captured") {
      const payment = e.payload?.payment?.entity;
      if (payment?.order_id && payment.id) {
        await markWebhookConfirmed(payment.order_id, payment.id, payment.notes?.productId ?? "lion-murti-stl");
      }
    }
    // payment.failed and other events are intentionally not fulfilled —
    // no receipt is written/upgraded, so no download can be issued for them.
  } catch {
    // Razorpay retries on non-2xx; respond 200 anyway once signature is valid
    // to avoid leaking internal errors, but log server-side for investigation.
    console.error("razorpay webhook: failed to persist receipt");
  }

  return NextResponse.json({ received: true });
}
