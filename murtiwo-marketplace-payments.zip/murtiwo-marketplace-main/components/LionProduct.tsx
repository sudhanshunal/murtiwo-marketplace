import Image from "next/image";
import { LION_MURTI_STL, formatPaiseAsINR } from "@/lib/products";
import { resolveImageUrl } from "@/lib/blob";
import { BuyNowButton } from "@/components/BuyNowButton";

export async function LionProduct() {
  let imageUrl: string | null = null;
  try {
    imageUrl = await resolveImageUrl(LION_MURTI_STL.imageBlobPathname);
  } catch {
    imageUrl = null;
  }

  return (
    <section id="lion-murti-stl" className="border-y border-white/5 bg-slate-950/30 py-24">
      <div className="mx-auto max-w-5xl px-6 lg:px-8">
        <p className="text-sm font-semibold uppercase tracking-[.18em] text-pink-300">Featured file</p>
        <div className="mt-6 grid gap-10 overflow-hidden rounded-3xl border border-white/10 bg-[#101628] p-6 sm:p-8 lg:grid-cols-2 lg:items-center">
          <div className="relative aspect-square overflow-hidden rounded-2xl bg-gradient-to-br from-amber-500/40 via-orange-500/15 to-transparent">
            {imageUrl ? (
              <Image
                src={imageUrl}
                alt={LION_MURTI_STL.name}
                fill
                sizes="(min-width: 1024px) 480px, 100vw"
                className="object-cover"
                unoptimized
              />
            ) : (
              <div className="grid h-full place-items-center text-sm text-slate-400">Preview image unavailable</div>
            )}
          </div>
          <div>
            <p className="text-xs font-semibold text-pink-300">{LION_MURTI_STL.formats.join(" · ")}</p>
            <h2 className="mt-2 font-display text-4xl">{LION_MURTI_STL.name}</h2>
            <p className="mt-4 max-w-md leading-7 text-slate-300">
              A detailed lion murti, ready for 3D printing or CAD refinement. Instant, protected download after
              payment — available in {LION_MURTI_STL.formats.join(" and ")} formats.
            </p>
            <div className="mt-6 flex items-center gap-4">
              <span className="font-display text-3xl">{formatPaiseAsINR(LION_MURTI_STL.priceInPaise)}</span>
            </div>
            <div className="mt-6">
              <BuyNowButton productId={LION_MURTI_STL.id} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
