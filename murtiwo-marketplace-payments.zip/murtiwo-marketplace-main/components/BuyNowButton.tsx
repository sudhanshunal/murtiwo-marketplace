"use client";

import { useState } from "react";
import Script from "next/script";

type CheckoutResponse = {
  orderId: string;
  amount: number;
  currency: string;
  keyId: string;
  productName: string;
};

type VerifyResponse = {
  verified: boolean;
  message: string;
  downloadUrl?: string;
};

type RazorpaySuccessResponse = {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
};

// Minimal typing for the Razorpay Checkout global loaded via <Script>.
type RazorpayInstance = {
  open: () => void;
  on: (event: "payment.failed", handler: (resp: { error?: { description?: string } }) => void) => void;
};
type RazorpayConstructor = new (options: Record<string, unknown>) => RazorpayInstance;

declare global {
  interface Window {
    Razorpay?: RazorpayConstructor;
  }
}

type Status = "idle" | "loading" | "cancelled" | "failed" | "verifying" | "success";

export function BuyNowButton({ productId }: { productId: string }) {
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState<string | null>(null);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [scriptReady, setScriptReady] = useState(false);

  async function handleBuyNow() {
    setStatus("loading");
    setMessage(null);
    setDownloadUrl(null);

    if (!scriptReady || !window.Razorpay) {
      setStatus("failed");
      setMessage("Checkout is still loading. Please try again in a moment.");
      return;
    }

    let order: CheckoutResponse;
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId }),
      });
      if (!res.ok) throw new Error("checkout failed");
      order = (await res.json()) as CheckoutResponse;
    } catch {
      setStatus("failed");
      setMessage("Could not start checkout. Please try again.");
      return;
    }

    const rzp = new window.Razorpay!({
      key: order.keyId,
      amount: order.amount,
      currency: order.currency,
      order_id: order.orderId,
      name: "Murtivo",
      description: order.productName,
      theme: { color: "#e11d48" },
      handler: async (response: RazorpaySuccessResponse) => {
        setStatus("verifying");
        try {
          const verifyRes = await fetch("/api/verify", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ productId, ...response }),
          });
          const data = (await verifyRes.json()) as VerifyResponse;
          if (verifyRes.ok && data.verified && data.downloadUrl) {
            setStatus("success");
            setMessage(data.message);
            setDownloadUrl(data.downloadUrl);
          } else {
            setStatus("failed");
            setMessage(data.message || "Payment could not be verified. No download was issued.");
          }
        } catch {
          setStatus("failed");
          setMessage("Payment could not be verified. No download was issued.");
        }
      },
      modal: {
        ondismiss: () => {
          setStatus("cancelled");
          setMessage("Payment cancelled. No charge or download.");
        },
      },
    });

    rzp.on("payment.failed", () => {
      setStatus("failed");
      setMessage("Payment could not be verified. No download was issued.");
    });

    rzp.open();
  }

  return (
    <div className="grid gap-3">
      <Script
        src="https://checkout.razorpay.com/v1/checkout.js"
        strategy="afterInteractive"
        onLoad={() => setScriptReady(true)}
      />
      <button
        type="button"
        onClick={handleBuyNow}
        disabled={status === "loading" || status === "verifying"}
        className="w-fit rounded-full bg-rose px-6 py-3 font-semibold text-slate-950 transition hover:bg-rose/90 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {status === "loading" ? "Starting checkout…" : status === "verifying" ? "Verifying payment…" : "Buy Now — ₹10"}
      </button>

      {message && (
        <p
          role="status"
          className={`text-sm font-medium ${
            status === "success" ? "text-emerald-400" : status === "cancelled" ? "text-slate-400" : "text-rose-400"
          }`}
        >
          {message}
        </p>
      )}

      {status === "success" && downloadUrl && (
        <>
          <a
            href={downloadUrl}
            download="Lion-Murti.stl"
            className="w-fit rounded-full border border-emerald-400/60 px-5 py-2.5 text-sm font-semibold text-emerald-300 transition hover:bg-emerald-400/10"
          >
            Download Lion Murti STL
          </a>
          <p className="text-xs text-slate-500">This download link expires in a few minutes for your security.</p>
        </>
      )}
    </div>
  );
}
